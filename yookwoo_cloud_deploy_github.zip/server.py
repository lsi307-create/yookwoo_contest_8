#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
[제8회 전국 대학생 육우요리대회] 심사 및 집계 통합 경량 로컬 서버 (방식 A)
Python 표준 라이브러리(http.server)만 사용하여 무설치(Zero Dependency)로 동작합니다.
"""

import http.server
import socketserver
import socket
import os
import sys
import json
import csv
import urllib.parse
from datetime import datetime

PORT = int(os.environ.get('PORT', 8000))
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, 'data')
os.makedirs(DATA_DIR, exist_ok=True)

FINAL_SCORES_FILE = os.path.join(DATA_DIR, 'final_scores.json')
PRELIM_SCORES_FILE = os.path.join(DATA_DIR, 'prelim_scores.json')
FINAL_TEAMS_CSV = os.path.join(DATA_DIR, 'final_teams.csv')
FINAL_TEAMS_JSON = os.path.join(DATA_DIR, 'final_teams.json')

def get_local_ip():
    """노트북/PC의 로컬 네트워크(Wi-Fi) IP 주소 자동 탐지"""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        # 실제 패킷을 보내지 않고 라우팅 가능한 로컬 IP 획득
        s.connect(('8.8.8.8', 80))
        ip = s.getsockname()[0]
    except Exception:
        ip = '127.0.0.1'
    finally:
        s.close()
    return ip

def load_json(filepath, default_val):
    if os.path.exists(filepath):
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception:
            return default_val
    return default_val

def save_json(filepath, data):
    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def load_final_teams():
    """data/final_teams.csv 또는 json에서 팀 목록 로드"""
    if os.path.exists(FINAL_TEAMS_CSV):
        try:
            teams = []
            with open(FINAL_TEAMS_CSV, 'r', encoding='utf-8-sig') as f:
                reader = csv.DictReader(f)
                for row in reader:
                    teams.append({
                        'id': int(row.get('번호', 0)),
                        'booth': row.get('부스번호', ''),
                        'univ': row.get('대학교명', ''),
                        'dept': row.get('학과명', ''),
                        'team': row.get('참가자', ''),
                        'title': row.get('요리명', ''),
                        'desc': row.get('요리설명', '')
                    })
            if teams:
                return teams
        except Exception as e:
            print("CSV read error:", e)
    return load_json(FINAL_TEAMS_JSON, [])

class ContestApiHandler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=BASE_DIR, **kwargs)

    def end_headers(self):
        # CORS 및 캐시 방지 헤더
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
        super().end_headers()

    def do_OPTIONS(self):
        self.send_response(200)
        self.end_headers()

    def send_json_response(self, data, status=200):
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.end_headers()
        self.wfile.write(json.dumps(data, ensure_ascii=False).encode('utf-8'))

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path

        # 루트 경로 접속 시 포털로 리디렉션
        if path == '/' or path == '':
            self.send_response(302)
            self.send_header('Location', '/portal.html')
            self.end_headers()
            return

        # API: 서버 IP 및 접속 URL 정보
        if path == '/api/info':
            render_url = os.environ.get('RENDER_EXTERNAL_URL')
            if render_url:
                self.send_json_response({
                    'ip': 'Cloud-Render',
                    'port': PORT,
                    'url': render_url.rstrip('/'),
                    'portalUrl': f'{render_url.rstrip("/")}/portal.html'
                })
                return

            ip = get_local_ip()
            self.send_json_response({
                'ip': ip,
                'port': PORT,
                'url': f'http://{ip}:{PORT}',
                'portalUrl': f'http://{ip}:{PORT}/portal.html'
            })
            return

        # API: 본선 팀 목록 조회
        if path == '/api/final/teams':
            teams = load_final_teams()
            self.send_json_response(teams)
            return

        # API: 본선 심사위원 점수 레지스트리 조회
        if path == '/api/final/scores':
            data = load_json(FINAL_SCORES_FILE, {})
            self.send_json_response(data)
            return

        # API: 예선 심사위원 점수 레지스트리 조회
        if path == '/api/prelim/scores':
            data = load_json(PRELIM_SCORES_FILE, {})
            self.send_json_response(data)
            return

        # 일반 정적 파일 서빙
        super().do_GET()

    def do_POST(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        length = int(self.headers.get('Content-Length', 0))
        body = self.rfile.read(length).decode('utf-8') if length > 0 else '{}'
        try:
            payload = json.loads(body)
        except Exception:
            payload = {}

        # API: 본선 채점 저장
        if path == '/api/final/score':
            judge = payload.get('judge', {})
            team_id = str(payload.get('teamId', ''))
            score_data = payload.get('scores', {})

            if not judge or not judge.get('id') or not team_id:
                self.send_json_response({'error': 'Invalid payload'}, 400)
                return

            registry = load_json(FINAL_SCORES_FILE, {})
            judge_id = judge['id']
            if judge_id not in registry:
                registry[judge_id] = {
                    'name': judge.get('name', ''),
                    'phone': judge.get('phone', ''),
                    'scores': {},
                    'lastActive': datetime.now().isoformat()
                }

            registry[judge_id]['scores'][team_id] = score_data
            registry[judge_id]['lastActive'] = datetime.now().isoformat()
            save_json(FINAL_SCORES_FILE, registry)

            self.send_json_response({'status': 'ok', 'savedAt': datetime.now().isoformat()})
            return

        # API: 예선 채점 저장
        if path == '/api/prelim/score':
            judge = payload.get('judge', {})
            recipe_id = str(payload.get('recipeId', ''))
            score_data = payload.get('scores', {})

            if not judge or not judge.get('id') or not recipe_id:
                self.send_json_response({'error': 'Invalid payload'}, 400)
                return

            registry = load_json(PRELIM_SCORES_FILE, {})
            judge_id = judge['id']
            if judge_id not in registry:
                registry[judge_id] = {
                    'name': judge.get('name', ''),
                    'phone': judge.get('phone', ''),
                    'scores': {},
                    'lastActive': datetime.now().isoformat()
                }

            registry[judge_id]['scores'][recipe_id] = score_data
            registry[judge_id]['lastActive'] = datetime.now().isoformat()
            save_json(PRELIM_SCORES_FILE, registry)

            self.send_json_response({'status': 'ok', 'savedAt': datetime.now().isoformat()})
            return

        # API: 점수 데이터 초기화
        if path == '/api/reset':
            stage = payload.get('stage', 'final')
            target_file = PRELIM_SCORES_FILE if stage == 'prelim' else FINAL_SCORES_FILE
            save_json(target_file, {})
            self.send_json_response({'status': 'reset_done', 'stage': stage})
            return

        self.send_json_response({'error': 'Not found'}, 404)

def run_server():
    if hasattr(sys.stdout, 'reconfigure'):
        try:
            sys.stdout.reconfigure(encoding='utf-8', errors='replace')
        except Exception:
            pass

    ip = get_local_ip()
    server_address = ('0.0.0.0', PORT)
    
    socketserver.TCPServer.allow_reuse_address = True
    with socketserver.TCPServer(server_address, ContestApiHandler) as httpd:
        print("=" * 65)
        print(" [제8회 전국 대학생 육우요리대회] 심사 집계 실시간 서버 시작 (방식 A)")
        print("=" * 65)
        print(f" * 현재 노트북(PC) 접속 주소 : http://localhost:{PORT}")
        print(f" * 심사위원 모바일/태블릿 주소 : http://{ip}:{PORT}")
        print("=" * 65)
        print(" * 주요 접속 링크:")
        print(f"   - [통합 포털] : http://{ip}:{PORT}/portal.html")
        print(f"   - [본선 심사] : http://{ip}:{PORT}/final.html")
        print(f"   - [예선 심사] : http://{ip}:{PORT}/prelim.html")
        print(f"   - [관리자 집계] : http://{ip}:{PORT}/admin.html")
        print("=" * 65)
        print(" [안내] 동일 Wi-Fi에 연결된 스마트폰/태블릿 브라우저 주소창에")
        print(f"        http://{ip}:{PORT} 를 입력하면 즉시 심사가 가능합니다.")
        print(" (종료하려면 Ctrl + C 를 누르세요)\n")
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\n서버를 정상적으로 종료했습니다.")

if __name__ == '__main__':
    run_server()
