@echo off
title Cloudflare Tunnel Login
cd /d "%~dp0"
echo ========================================================
echo   Cloudflare Tunnel Login
echo   Opening browser for Cloudflare authentication...
echo ========================================================
echo.
"%~dp0cloudflared.exe" tunnel login
echo.
echo ========================================================
echo   Authentication finished. You can close this window.
echo ========================================================
pause
