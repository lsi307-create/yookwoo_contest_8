#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
[제8회 전국 대학생 육우요리대회] 실시간 통합 시스템 원클릭 런처 (방식 A + Cloudflare)
1. 로컬 백엔드 서버(server.py) 실행
2. Cloudflare 보안 터널(cloudflared.exe) 실행 및 퍼블릭 HTTPS URL 감지
3. 디버깅 제어판(tunnel_debug.html) 브라우저 자동 오픈
"""

import subprocess
import threading
import webbrowser
import time
import re
import sys
import os

if hasattr(sys.stdout, 'reconfigure'):
    try:
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    except Exception:
        pass

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, 'data')
os.makedirs(DATA_DIR, exist_ok=True)
PUBLIC_URL_FILE = os.path.join(DATA_DIR, 'public_url.txt')

server_proc = None
tunnel_proc = None

def clean_shutdown():
    global server_proc, tunnel_proc
    print("\n[안내] 서버와 Cloudflare 터널을 안전하게 종료합니다...")
    if tunnel_proc:
        try:
            tunnel_proc.terminate()
        except Exception:
            pass
    if server_proc:
        try:
            server_proc.terminate()
        except Exception:
            pass
    try:
        if os.path.exists(PUBLIC_URL_FILE):
            os.remove(PUBLIC_URL_FILE)
    except Exception:
        pass
    print("[완료] 모든 프로세스가 종료되었습니다.")

def main():
    global server_proc, tunnel_proc

    print("=" * 68)
    print(" [제8회 전국 대학생 육우요리대회] 실시간 심사 & Cloudflare 통합 시스템")
    print("=" * 68)

    # 1. Start server.py
    print(" 1. 로컬 백엔드 서버(포트 8000)를 구동합니다...")
    server_proc = subprocess.Popen(
        [sys.executable, 'server.py'],
        cwd=BASE_DIR,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL
    )
    time.sleep(1.2)

    # 2. Start cloudflared tunnel
    print(" 2. Cloudflare 보안 터널을 연결하여 글로벌 HTTPS 주소를 발급받습니다...")
    cloudflared_exe = os.path.join(BASE_DIR, 'cloudflared.exe')
    if not os.path.exists(cloudflared_exe):
        print(" [경고] cloudflared.exe를 찾을 수 없어 로컬 모드로만 실행합니다.")
        webbrowser.open('http://localhost:8000/tunnel_debug.html')
        server_proc.wait()
        return

    tunnel_proc = subprocess.Popen(
        [cloudflared_exe, 'tunnel', '--url', 'http://localhost:8000'],
        cwd=BASE_DIR,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        encoding='utf-8',
        errors='replace'
    )

    # 3. Read output to detect trycloudflare.com URL
    detected_url = None
    start_time = time.time()
    while time.time() - start_time < 15:
        line = tunnel_proc.stderr.readline()
        if line:
            m = re.search(r'https://[a-zA-Z0-9-]+\.trycloudflare\.com', line)
            if m:
                detected_url = m.group(0)
                break
        time.sleep(0.1)

    if detected_url:
        with open(PUBLIC_URL_FILE, 'w', encoding='utf-8') as f:
            f.write(detected_url)
        print("=" * 68)
        print(" [성공] Cloudflare 보안 터널이 정상적으로 활성화되었습니다!")
        print("=" * 68)
        print(f" ▶ 글로벌 공개 접속 주소 (HTTPS) : {detected_url}")
        print(f" ▶ 심사위원 본선 채점 페이지 : {detected_url}/final.html")
        print(f" ▶ 운영사무국 관리자 대시보드 : http://localhost:8000/admin.html")
        print(f" ▶ 디버깅 & 배포 제어판 (QR) : http://localhost:8000/tunnel_debug.html")
        print("=" * 68)
        print(" [안내] 심사위원들은 Wi-Fi 연결 없이 본인 폰(LTE/5G)으로 위 주소에 접속하면 됩니다.")
        print(" (종료하려면 이 창에서 Ctrl + C 를 누르세요)\n")
    else:
        print(" [알림] 터널 주소 자동 감지 대기 중... 로컬 제어판을 엽니다.")

    # 4. Open Debugging Page in Browser
    try:
        webbrowser.open('http://localhost:8000/tunnel_debug.html')
    except Exception:
        pass

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        clean_shutdown()

if __name__ == '__main__':
    main()
