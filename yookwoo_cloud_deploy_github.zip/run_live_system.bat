@echo off
title Contest Live System
cd /d "%~dp0"
echo Starting Contest System...
if exist "%~dp0python\python.exe" (
    "%~dp0python\python.exe" run_live_system.py
) else (
    python run_live_system.py
)
pause
