@echo off
title Contest Server Local Mode
cd /d "%~dp0"
echo Starting Contest Local Server...
if exist "%~dp0python\python.exe" (
    "%~dp0python\python.exe" server.py
) else (
    python server.py
)
pause
