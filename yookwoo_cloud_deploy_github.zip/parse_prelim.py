import json
import csv
import io

raw_csv = """번호,작성자,제목,작성일,게시글 URL
1,henry,육우 비프타르타르,2026-06-08 00:11:33,https://yookoo.ziggleziggle.com/forums/Q0ZDO0R4Q/threads/T4LQJXR6R
2,dohyeon,한국 식재료와 육우를 활용해 풀어낸 건강한 한 접시,2026-06-07 23:59:30,https://yookoo.ziggleziggle.com/forums/Q0ZDO0R4Q/threads/T4LQJI9CJ
3,육우사랑,"자연을 담은 5색 야채 샤를로트 링과 육우 안심 , 토마토라구 알라 파나",2026-06-07 23:58:36,https://yookoo.ziggleziggle.com/forums/Q0ZDO0R4Q/threads/T4LQJH3MQ
4,신혜원,갈비 육우 웰링턴,2026-06-07 23:39:02,https://yookoo.ziggleziggle.com/forums/Q0ZDO0R4Q/threads/T4LQIRXQW
5,vonvon,"된장의 바다, 육우의 들판",2026-06-07 23:34:16,https://yookoo.ziggleziggle.com/forums/Q0ZDO0R4Q/threads/T4LQILT0L
6,vonvon,"350년, 육우로 되살린 고조리서 육면",2026-06-07 23:27:35,https://yookoo.ziggleziggle.com/forums/Q0ZDO0R4Q/threads/T4LQID7IP
7,박채원,"육우 타르타르, 전복 타르트",2026-06-07 23:16:10,https://yookoo.ziggleziggle.com/forums/Q0ZDO0R4Q/threads/T4LQHYJ3U
8,주희수,한식 풍미를 담은 육우 떡갈비 아란치니 with 알프레도 소스 · 깻잎 페스토 · 참외 피클,2026-06-07 22:44:49,https://yookoo.ziggleziggle.com/forums/Q0ZDO0R4Q/threads/T4LQGU7WR
9,고동환,카르네살라다 기법으로 염지한 이탈리아 북부식 인볼티니와 바투타,2026-06-07 21:50:08,https://yookoo.ziggleziggle.com/forums/Q0ZDO0R4Q/threads/T4LQEVVTQ
10,황연서,육우 정원 타르트,2026-06-07 21:31:17,https://yookoo.ziggleziggle.com/forums/Q0ZDO0R4Q/threads/T4LQE7N5I
11,youngg,Beef & Crust[비프 앤 크러스트],2026-06-07 21:02:25,https://yookoo.ziggleziggle.com/forums/Q0ZDO0R4Q/threads/T4LQD6J4H
12,우장금,牛호전을 곁들인 초牛탕,2026-06-07 20:36:08,https://yookoo.ziggleziggle.com/forums/Q0ZDO0R4Q/threads/T4LQC8PVV
13,SOOSSO,육우샌드 3종과 육우 굴림 만두,2026-06-07 20:25:39,https://yookoo.ziggleziggle.com/forums/Q0ZDO0R4Q/threads/T4LQBV8U9
14,강현서,들깨 육회 비빔 면,2026-06-07 18:36:39,https://yookoo.ziggleziggle.com/forums/Q0ZDO0R4Q/threads/T4LQ7Z2NF
15,이종서,"고추장라구 소스를 채운 육우 아란치니 , 그린 로메스코 소스",2026-06-07 18:09:47,https://yookoo.ziggleziggle.com/forums/Q0ZDO0R4Q/threads/T4LQ70IF1
16,어머니들오늘저녁은제가책임집니다,"간단건강쇠고기전골과 땅콩소스",2026-06-07 16:22:00,https://yookoo.ziggleziggle.com/forums/Q0ZDO0R4Q/threads/T4LQ35WI4
17,야르,"육우, 옥수수, 명이",2026-06-07 16:12:20,https://yookoo.ziggleziggle.com/forums/Q0ZDO0R4Q/threads/T4LQ2TGXE
18,youn,육우 황금실타래,2026-06-07 15:03:42,https://yookoo.ziggleziggle.com/forums/Q0ZDO0R4Q/threads/T4LQ0D7S8
19,youn,육우꽃주머니,2026-06-07 14:29:38,https://yookoo.ziggleziggle.com/forums/Q0ZDO0R4Q/threads/T4LPZ5EKK
20,나킹이유,오디뽕주와 된장 향의 육우 비프 부르기뇽,2026-06-07 14:23:23,https://yookoo.ziggleziggle.com/forums/Q0ZDO0R4Q/threads/T4LPYXDIN
21,조현우,육우 웰링턴 ,2026-06-07 14:13:31,https://yookoo.ziggleziggle.com/forums/Q0ZDO0R4Q/threads/T4LPYKOKH
22,김진오,육우 안심을 이용한 메인 플레이트 ,2026-06-07 13:51:31,https://yookoo.ziggleziggle.com/forums/Q0ZDO0R4Q/threads/T4LPXSE4V
23,Jueun08,누룩 숙성 안심 소고기 육우와 볏짚 버터 베이스팅,2026-06-07 13:49:55,https://yookoo.ziggleziggle.com/forums/Q0ZDO0R4Q/threads/T4LPXQBVC
24,해피아이쿠킹,"“배품은 육우, 된장을 입다.”",2026-06-07 13:20:53,https://yookoo.ziggleziggle.com/forums/Q0ZDO0R4Q/threads/T4LPWOZXC
25,송정원,미나리를 곁들인 육우 겨자냉채와 냉국밥,2026-06-07 12:27:37,https://yookoo.ziggleziggle.com/forums/Q0ZDO0R4Q/threads/T4LPUSHHE
26,최인종,트러플참깨 스테이크 파스타,2026-06-07 09:58:19,https://yookoo.ziggleziggle.com/forums/Q0ZDO0R4Q/threads/T4LPPGHWE
27,박은총,토마토갈비찜,2026-06-07 08:36:25,https://yookoo.ziggleziggle.com/forums/Q0ZDO0R4Q/threads/T4LPMJ5P4
28,쌈윤,牛마MEAT 국수,2026-06-07 04:56:00,https://yookoo.ziggleziggle.com/forums/Q0ZDO0R4Q/threads/T4LPENPJI
29,우어지마,무 라비올리를 곁들인 육우 라구 주먹밥,2026-06-06 23:46:49,https://yookoo.ziggleziggle.com/forums/Q0ZDO0R4Q/threads/T4LP3M3PE
30,동작구어린이사회복지급식관리지원센터,두유크림소스에 담긴 소고기양배추롤,2026-06-06 23:21:23,https://yookoo.ziggleziggle.com/forums/Q0ZDO0R4Q/threads/T4LP2PE2R
31,준더,"치마 라자냐자냐~ [장맛을 입은 육우 치마살 라자냐]",2026-06-06 23:09:53,https://yookoo.ziggleziggle.com/forums/Q0ZDO0R4Q/threads/T4LP2ALL2
32,조완수,유자 한방소스 타다끼와 영양부추 무침,2026-06-06 22:16:12,https://yookoo.ziggleziggle.com/forums/Q0ZDO0R4Q/threads/T4LP0DK89
33,mixxxol,오방색 발효 플레이트와 마늘미소 채끝 스테이크,2026-06-06 16:51:29,https://yookoo.ziggleziggle.com/forums/Q0ZDO0R4Q/threads/T4LOORYRA
34,리짜로,육우 양지로 끓여낸 맑은 뇨끼 수프,2026-06-06 15:07:09,https://yookoo.ziggleziggle.com/forums/Q0ZDO0R4Q/threads/T4LOL1SNQ
35,김서0진,"간장 브레이즈 육우 뽈살 크로켓 & 깻잎 마요네즈, 참외 피클",2026-06-06 14:46:25,https://yookoo.ziggleziggle.com/forums/Q0ZDO0R4Q/threads/T4LOKB4XQ
36,최재성,진피된장소스를 곁들인 육우 등심 무 찜,2026-06-05 23:42:16,https://yookoo.ziggleziggle.com/forums/Q0ZDO0R4Q/threads/T4LNO0EAY
37,멘샤,한우 목심으로 만든 달달한 소보루규동,2026-06-05 20:39:11,https://yookoo.ziggleziggle.com/forums/Q0ZDO0R4Q/threads/T4LNHGYCB
38,Charlie,차돌 당귀 알리오 올리오,2026-06-05 13:52:44,https://yookoo.ziggleziggle.com/forums/Q0ZDO0R4Q/threads/T4LN2Y8IB
39,육우남,불고기샌드위치,2026-06-04 23:37:01,https://yookoo.ziggleziggle.com/forums/Q0ZDO0R4Q/threads/T4LM8DSL4
40,길위의셰프,<육우 고추장 타코라이스>,2026-06-04 23:20:33,https://yookoo.ziggleziggle.com/forums/Q0ZDO0R4Q/threads/T4LM7SLXI
41,김찬영,배된장 소스를 곁들인 육우 등심 미나리 솥밥,2026-06-04 21:17:40,https://yookoo.ziggleziggle.com/forums/Q0ZDO0R4Q/threads/T4LM3EKXL
42,조미모,갈비맛 육우 스테이크,2026-06-04 18:06:28,https://yookoo.ziggleziggle.com/forums/Q0ZDO0R4Q/threads/T4LLWKPGK
43,김민혁,일본식우삼겹덮밥,2026-06-04 11:03:25,https://yookoo.ziggleziggle.com/forums/Q0ZDO0R4Q/threads/T4LLHGNDH
44,SW,육.표.고.로 <육우 표고 구이와 고추장 로메스코>,2026-06-04 08:48:47,https://yookoo.ziggleziggle.com/forums/Q0ZDO0R4Q/threads/T4LLCNIGM
45,세윤,육우 비프 스튜 & 매쉬포테이토,2026-06-04 00:39:41,https://yookoo.ziggleziggle.com/forums/Q0ZDO0R4Q/threads/T4LKV6IVK
46,은서태호,매콤소민찌가지볶음덮밥,2026-06-03 16:24:57,https://yookoo.ziggleziggle.com/forums/Q0ZDO0R4Q/threads/T4LKDIAOE
47,박윤창,육우 타르타르 _ 발사믹 비네거와 피넛버터를 곁들인 육우 타르타르,2026-06-03 15:19:40,https://yookoo.ziggleziggle.com/forums/Q0ZDO0R4Q/threads/T4LKB6CJO
48,돼지호,5. 육우 타레 숯불 구이 덮밥 (육우 레시피 응모),2026-06-02 16:59:47,https://yookoo.ziggleziggle.com/forums/Q0ZDO0R4Q/threads/T4LIZB8LI
49,검은털레오,오리엔탈 육우 라이스페이퍼 롤,2026-06-02 09:03:21,https://yookoo.ziggleziggle.com/forums/Q0ZDO0R4Q/threads/T4LIIAJOJ
50,짜온,육우 케일롤,2026-06-01 09:10:46,https://yookoo.ziggleziggle.com/forums/Q0ZDO0R4Q/threads/T4LH3480F
51,Dian,육우 삼중주 (3가지를 담았다는 의미),2026-05-31 20:29:21,https://yookoo.ziggleziggle.com/forums/Q0ZDO0R4Q/threads/T4LGBX1LC
52,띠안,육우 야채고기말이 튀김,2026-05-30 00:30:55,https://yookoo.ziggleziggle.com/forums/Q0ZDO0R4Q/threads/T4LDPNZX3
53,육우육우,육우 된장 부르기뇽,2026-05-28 14:32:59,https://yookoo.ziggleziggle.com/forums/Q0ZDO0R4Q/threads/T4LBOV70Q
54,수크림,육우 본앤브리스킷 (Bone & Brisket) 파이,2026-05-25 16:47:39,https://yookoo.ziggleziggle.com/forums/Q0ZDO0R4Q/threads/T4L7JCTJH
55,오진호,된장육슬,2026-05-19 21:14:50,https://yookoo.ziggleziggle.com/forums/Q0ZDO0R4Q/threads/T4KZ89B5Q
56,핑하,간단하지만 맛있는 두릅말이!,2026-05-19 10:39:32,https://yookoo.ziggleziggle.com/forums/Q0ZDO0R4Q/threads/T4KYLKAPE
57,류동열,한입으로 챙기는 건강소떡소떡 ,2026-05-19 01:23:02,https://yookoo.ziggleziggle.com/forums/Q0ZDO0R4Q/threads/T4KY1ONE0
"""

reader = csv.DictReader(io.StringIO(raw_csv.strip()))
items = []
for row in reader:
    items.append({
        'id': int(row['번호']),
        'author': row['작성자'].strip(),
        'title': row['제목'].strip().replace('\n', ' '),
        'date': row['작성일'].strip(),
        'url': row['게시글 URL'].strip()
    })

output_path = r'C:\Users\lsi30\.gemini\antigravity\scratch\yookwoo_cardnews_page\prelim_data.json'
with open(output_path, 'w', encoding='utf-8') as f:
    json.dump(items, f, ensure_ascii=False, indent=2)

print(f"Successfully saved {len(items)} recipes to prelim_data.json")
